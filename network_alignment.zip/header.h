//
// Created by 李博 on 2019/2/7.
//

#ifndef NETWORK_ALIGNMENT_HEADER_H
#define NETWORK_ALIGNMENT_HEADER_H

#include <iostream>
#include <cstring>
#include <algorithm>
#include <stack>
#include <vector>
#include <queue>
#include <cstdlib>
#include <fstream>
#include <cstdio>
#include <set>
#include <map>
#define mem(x) memset(x,0,sizeof(x))

#endif //NETWORK_ALIGNMENT_HEADER_H
